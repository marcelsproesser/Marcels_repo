# Curso: Big Data e Inteligência Analítica
# Estudante: Marcel Sproesser Mathias

import random

# Declarando os objetos e lista de dados

dado_verde = "CPCTCP"
dado_amarelo = "TPCTPC"
dado_vermelho = "TPTCPT"

dados_disponiveis = [dado_amarelo, dado_amarelo, dado_amarelo,
                     dado_amarelo, dado_vermelho, dado_vermelho,
                     dado_vermelho, dado_vermelho, dado_verde,
                     dado_verde, dado_verde, dado_verde, dado_verde,
                     dado_verde]

# "Mainframe"
# Função while para não permitir que inicie o jogo com menos de dois jogadores

print("Bem vinda/o/e ao jogo X")

quantidade_jogadores = int(input("Quantas pessoas vão jogar? "))
while quantidade_jogadores < 2:
    print("Não é permitido menos de 2 jogadores")
    quantidade_jogadores = int(input("Quantas pessoas vão jogar? "))

# Função for para pedir o nome dos jogadores e atribuir os dados inseridos na lista "lista_jogadores"
lista_jogadores = []
for i in range(quantidade_jogadores):
    nome = input("Insira o nome do jogador " + str(i+1) + ": ")
    lista_jogadores.append(nome)
print(lista_jogadores)

# possibilidade de adicionar mais jogadores
adicionar_jogador = 0
while adicionar_jogador != "n":
    adicionar_jogador = input("Você quer adicionar mais jogadores? " + str(lista_jogadores) + " (s/n): ")
    if adicionar_jogador == "s":
        nome = input("Insira o nome do novo jogador: ")
        lista_jogadores.append(nome)

# Garantindo que o número atribuido ao objeto quantidade_jogadores seja atualizado com a entrada de novos jogadores
quantidade_jogadores = len(lista_jogadores)

# Declarando objetos relacionados a pontuação
jogador_atual = 0
dados_sorteados = []
tiros: int = 0
cerebros: int = 0
passos: int = 0
quantidade_dados = 0

# Inicio do jogo, funções while para o jogador inserir "comandos" e selecionar as opções possíeis para jogar
# Demonstrando qual jogador está jogando no momento
print("Começando o jogo")

continuar_jogo = 0
turno = 0
while True:

    # Adicionei essa função para não rodar o jogo todo de uma vez

    rolar_dado = 0
    while rolar_dado != "1":
        if continuar_jogo == "N":
            turno = turno + 1
        print("Turno do jogador: " + str(lista_jogadores[turno]))
        rolar_dado = input("Para rolar o dado digite 1: ")
    # Função for para rodar apenas 3 dados
    for i in range(3):
        # Utilizando a biblioteca random para sortear o dado escolhido, 0 a 12 sendo relacionado a cada objeto na lista
        numero_sorteado = random.randint(0, 12)
        dado_aleatorio = dados_disponiveis[numero_sorteado]

        # Condições para o programa apresentar qual dado foi escolhido/tirado

        if dado_aleatorio == "CPCTPC":
            cor_dado = "verde"
        elif dado_aleatorio == "TPCTPC":
            cor_dado = "amarelo"
        else:
            cor_dado = "Vermelho"

        print("O dado sorteado foi o ", cor_dado)
        dados_sorteados.append(dado_aleatorio)

    print("Os lados sorteados foram ")
    # Função for para selecionar um objeto dentro de dados_sorteados e utilizar a função random.randint da biblioteca random para selecionar uma face de maneira aleatória
    for dado_aleatorio in dados_sorteados:
        num_face_dado = random.randint(0, 5)
        # Condições para o programa apresentar qual face do dado foi escolhida/tirada
        if dado_aleatorio[num_face_dado] == "C":
            print("Você comeu um cérebro")
            cerebros = cerebros + 1
        elif dado_aleatorio[num_face_dado] == "P":
            print("A vítima fugiu")
            passos = passos + 1
        else:
            print("Você tomou um tiro")
            tiros = tiros + 1
    # Função apontando a pontuação do jogador
    print("Score atual: ")
    print("Cérebros comidos: ", cerebros)
    print("Tiros disparados: ", tiros)
    # Condições que determinam se o jogador venceu ou perdeu o jogo
    if cerebros >= 13:
        print("Parabéns você ganhou o jogo!!")
        break
    elif tiros >= 3:
        print("Você perdeu  o jogo")
        break
    else:
        # Função para passar de turno
        continuar_jogo = input("Você deseja continuar jogando? (S/N) ")
        if continuar_jogo == "N":
            jogador_atual = jogador_atual + 1
            dados_sorteados = []
            tiros = 0
            cerebros = 0
            passos = 0

        # Condições para determinar se o jogo está encerrado ou se irá para o próximo turno
        if jogador_atual >= quantidade_jogadores:
            print("Finalizando o jogo")
            break

        else:
            print("Iniciando mais uma rodada")
            dados_sorteados = []
